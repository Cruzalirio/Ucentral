library(mgcv)
library(gamlss)
library(spdep)
library(sphet)
library(spatialreg)
library(pracma)
library(OpenMx)
library(reshape2)
library(ggplot2)
library(tidyverse)
library(readr)
library(Rdistance)
library(readxl)
library(optimParallel)
rm(list=ls())


GEESAR <- function (formula, family = gaussian(), weights = NULL, data, W,
                    corr, start = NULL,
                    toler = 1e-04, maxit = 200, trace = FALSE, ...) {
  mf <- model.frame(formula, data=data)
  y <- as.matrix(model.response(mf))
  if (is(family, "function")) 
    family <- family()
  if (family$family %in% c("quasi", "quasibinomial", "quasipoisson")) {
    if (family$family == "quasi") {
      family$family <- switch(family$varfun, constant = "gaussian", 
                              `mu(1-mu)` = "binomial", mu = "poisson", `mu^2` = "Gamma", 
                              `mu^3` = "inverse.gaussian")
    }
    else {
      family$family <- switch(family$family, quasibinomial = "binomial", 
                              quasipoisson = "poisson")
    }
    family <- do.call(family$family, list(link = family$link))
    family2 <- family
  }else {
    if (family$family %in% c("gaussian", "binomial", "poisson", 
                             "Gamma", "inverse.gaussian")) {
      varfun <- switch(family$family, gaussian = "constant", 
                       binomial = "mu(1-mu)", poisson = "mu", Gamma = "mu^2", 
                       inverse.gaussian = "mu^3")
      family2 <- do.call("quasi", list(variance = varfun, 
                                       link = family$link))
      if (family$family == "binomial") 
        family2 <- do.call("quasibinomial", list(link = family$link))
      if (family$family == "poisson") 
        family2 <- do.call("quasipoisson", list(link = family$link))
    }else family2 <- family
  }
  if (ncol(y) == 2 & family$family == "binomial") {
    weights <- as.matrix(y[, 1] + y[, 2])
    y <- as.matrix(y[, 1]/weights)
  }
  y <- as.matrix(as.numeric(y))
  offset <- as.vector(model.offset(mf))
  X <- model.matrix(formula, data)
  p <- ncol(X)
  n <- nrow(X)
  if (is.null(offset)){ 
    offs <- matrix(0, n, 1)}else{ offs <- as.matrix(offset)}
  if (is.null(weights)) {
    weights <- matrix(1, n, 1)} else {
      weights <- as.matrix(weights)}
  if (any(weights <= 0)) 
    stop("Only positive weights are allowed!!", call. = FALSE)
  datas <- cbind(X,y, offs, weights)
  
  
  qll <- NULL
  if (family$family == "gaussian") 
    qll <- function(weights, y, mu) -weights * (y - mu)^2/2
  if (family$family == "binomial") 
    qll <- function(weights, y, mu) weights * (y * log(mu) + (1 - y) * log(1 - mu))
  if (family$family == "poisson") 
    qll <- function(weights, y, mu) weights * (y * log(mu) - mu)
  if (family$family == "Gamma") 
    qll <- function(weights, y, mu) -weights * (y/mu + log(mu))
  if (family$family == "inverse.gaussian") 
    qll <- function(weights, y, mu) weights * (mu - y/2)/mu^2
  if (family$family == "Negative Binomial") {
    .Theta <- function() return(.Theta)
    environment(.Theta) <- environment(family$variance)
    .Theta <- .Theta()
    qll <- function(weights, y, mu) weights * (y * log(mu/(mu + .Theta)) + .Theta * 
                                                 log(.Theta/(.Theta + mu)))
  }
  if (family$family == "Tweedie") {
    .Theta <- function() return(p)
    environment(.Theta) <- environment(family$variance)
    .Theta <- .Theta()
    if (.Theta %in% c(0, 1, 2)) {
      if (.Theta == 0) 
        qll <- function(weights, y, mu) -weights * (y - mu)^2/2
      if (.Theta == 1) 
        qll <- function(weights, y, mu) weights * (y * log(mu) - mu)
      if (.Theta == 2) 
        qll <- function(weights, y, mu) -weights * (y/mu + log(mu))
    }
    else qll <- function(weights, y, mu) mu^(-.Theta) * (mu * y/(1 - .Theta) - mu^2/(2 - 
                                                                                       .Theta))
  }
  if (is.null(qll)) 
    qll <- function(weights, y, mu) family$dev.resids(y, mu, weights)
  
  qllp <- function(rho, beta, W, D,n){
    p = nrow(beta)
    A = diag(n) - rho*W
    Xi <-solve(A)%*%matrix(D[, 1:p], ncol = p)
    yi <- D[, p + 1]
    ni <- nrow(Xi)
    etai <- Xi %*% beta + D[, p + 2]
    mui <- family$linkinv(etai[,1])
    QL <- sum(qll(weights=D[,p+3], y=D[,p+1], mu=mui))
    return(-QL)
  }
  score <- function(D, W, rho, beta, ni, simR=TRUE) {
    A = diag(ni) - rho*W
    Xi <-solve(A)%*%matrix(D[, 1:p], ncol = p)
    yi <- D[, p + 1]
    ni <- nrow(Xi)
    etai <- Xi %*% beta + D[, p + 2]
    mui <- family$linkinv(etai[,1])
    wi <- sqrt(family$variance(mui)/D[, p + 3])
    Xiw <- Xi * matrix(family$mu.eta(etai[,1]), nrow(Xi), p)
    Vi <- diag(family$mu.eta(etai[,1]))%*%
      cov2cor(solve(crossprod(A))) %*% 
      diag(family$mu.eta(etai[,1])) 
    Vi <- t( cov2cor(solve(crossprod(A))) * matrix(wi, ni, ni)) * matrix(wi, ni, ni)
    Vi2 <- try(chol2inv(chol(Vi)), silent=TRUE)
    if(!is.matrix(Vi2)){Vi2 =MASS::ginv(as.matrix(Vi))}
    Xiw2 <- crossprod(Vi2, Xiw)
    cbind(crossprod(Xiw2, (yi - mui)), crossprod(Xiw2,Xiw), 
          crossprod(Xiw2, (tcrossprod(yi - mui)) %*% Xiw2))
  }
  
  rho <- 0
  A = diag(n) - rho*W
  X0 = cbind(X, W%*%y)
  beta_new <- try(glm.fit(y = y, x = X0, family = family2, 
                          weights = weights, offset = offs), silent = TRUE)
  beta_new <- matrix(beta_new$coefficients[1:p], nrow=p)
  rho_f <- optim(par=rho,qllp, beta=beta_new, W=W, 
                 D=datas,n=n, method="L-BFGS-B", lower=-0.99,upper=0.99)
  rho_new <- rho_f$par
  tolrho <- 1
  niterrho <- 1

  Result <- rho_new
  while(tolrho>toler & niterrho < maxit){
    rho <- rho_new
    A = diag(n) - rho*W
    mod1 <- glmtoolbox::glmgee(y~as.matrix(solve(A)%*%X)-1,family=family,
                                corstr = "User-defined", 
                               corr = as.matrix(solve(tcrossprod(A))),
                               id=rep(1,n))
    beta_new <- mod1$coefficients
    rho_f <- optim(par=rho,qllp, beta=beta_new, W=W, D=datas, n=n,
                   method="L-BFGS-B", lower=-0.99,upper=0.99)
    rho_new <- rho_f$par
    tolrho <- abs(rho_new-rho)
    print(niterrho)
    niterrho <- niterrho + 1
    Result = c(Result, rho_new)
  }
  rho <- rho_new
  A = diag(n) - rho*W
  rownames(beta_new) <- colnames(X)
  colnames(beta_new) <- ""
  if (niterrho == maxit) 
    warning("Iteration limit exceeded!!\n", call. = FALSE)
  eta <- solve(A)%*% X %*% beta_new + offs
  mu <- family$linkinv(eta[,1])
  phiis <- diag(solve(crossprod(A)))
  vari <- sqrt(family$variance(mu)/datas[, p + 3]*phiis)
  phi <- sum(((y-mu)/sqrt(vari))^2)/(n-p)
  sera <- try(chol(R), silent = TRUE)
  #varrho <- Rdistance::secondDeriv(rho, qllp,beta=beta_new, W=W, D=datas, n=n)
  I0 <- mod1$naive
  I1 <- solve(mod1$naive)
  RJC <- crossprod(I0, I1)
  vcovs <- RJC %*% I0
  rownames(vcovs) <- colnames(X)
  colnames(vcovs) <- colnames(X)
  
  w <- sqrt(weights * family2$mu.eta(eta[,1])^2/family2$variance(mu))
  Xw <- matrix(w, nrow(X), ncol(X)) * X
  CIC <- sum(diag((crossprod(Xw)/phi) %*% vcovs))
  RJC <- sqrt((1 - sum(diag(RJC))/(p * phi))^2 + (1 - sum(diag(RJC %*% 
                                                                 RJC))/(p * phi^2))^2)
  logLik <- -qllp(rho=rho, W=W, D=datas, beta=beta_new, n=n)/phi
  estfun <- mod1$estfun
  rownames(estfun) <- colnames(X)
  colnames(estfun) <- ""
  out_ <- list(coefficients = beta_new, rho=rho,  fitted.values = mu, 
               linear.predictors = eta,  arrangedata = datas, 
               prior.weights = weights, y = y, formula = formula, call = match.call(), 
               offset = offs, model = mf, data = data, tracerho = Result,
               score = score, converged = ifelse(niterrho < maxit, TRUE, FALSE), estfun = estfun, 
               naive = I0,  family = family,  phi = phi, phiis = phiis, CIC = CIC, RJC = RJC, 
               logLik = logLik, deviance = sum(family$dev.resids(y, mu, weights)), df.residual = length(y) - length(beta_new), 
               levels = .getXlevels(attr(mf, "terms"), mf),
               contrasts = attr(X, "contrasts"), start = start, iter = niterrho, linear = TRUE)
  class(out_) <- "glmgee"
  return(out_)
}



setwd("~/2024/GEESAR/CensoUS")

Votos <- read_csv("2020_US_County_Level_Presidential_Results.csv")
Educacion <- read_excel("Education.xlsx", 
                        skip = 3)
Pobreza <- read_excel("PovertyEstimates.xlsx")
Desempleo <- read_excel("Unemployment.xlsx", skip = 4)
SDData <- read_csv("co-est2021-alldata.csv")


DataModel <- Votos %>%
  dplyr::mutate(votes=REPUBLICAN+DEMOCRAT) %>% 
  dplyr::mutate(votesREP=REPUBLICAN/votes) %>% 
  left_join(Educacion %>% 
              mutate(county_fips=as.numeric(as.character(`FIPS Code`))), by=c("county_fips"))%>%
  left_join(Desempleo%>% 
              mutate(county_fips=as.numeric(as.character(FIPS_Code))), by=c("county_fips"))%>%
  left_join(Pobreza %>% 
              mutate(county_fips=as.numeric(as.character(FIPS_Code))), by=c("county_fips")) %>% 
  left_join(SDData%>% 
              mutate(county_fips=as.numeric(as.character(paste(STATE, COUNTY, sep="")))), by=c("county_fips")) %>% 
  dplyr::mutate(Id =county_fips, state= state,
                PorcLess = `Percent of adults with less than a high school diploma, 2018-22`,
                PorcHigh = `Percent of adults with a high school diploma only, 2018-22`,
                PorcOverHigh =`Percent of adults completing some college or associate's degree, 2018-22`,
                PorcBachelor = `Percent of adults with a bachelor's degree or higher, 2018-22`) %>% 
  dplyr::mutate(TasaNac =100000*BIRTHS2020/POPESTIMATE2020, 
                PorcMigInt = 100000*INTERNATIONALMIG2020/POPESTIMATE2020, 
                Poverty = POVALL_2021/POPESTIMATE2021, 
                MEDHHINC_2021=MEDHHINC_2021/1000, 
                Civilian_labor_force_2020 = Civilian_labor_force_2020/POPESTIMATE2020,
                Employed_2020 = Employed_2020/POPESTIMATE2020,
                IndRep = ifelse(votesREP>0.5, 1, 0)) %>% 
  dplyr::select(Id, state,votes, DEMOCRAT, GREEN,
                LIBERTARIAN, OTHER, REPUBLICAN,POVALL_2021, MEDHHINC_2021,
                Civilian_labor_force_2020, Employed_2020,Unemployment_rate_2020,
                PorcLess, PorcHigh, PorcOverHigh, PorcBachelor, votesREP,
                TasaNac, PorcMigInt, Poverty, IndRep) 


urlA = "cb_2018_us_county_500k/cb_2018_us_county_500k.shp"
USC =read_sf(urlA)

USC <- USC %>% dplyr::mutate(Id = as.numeric(paste(STATEFP, COUNTYFP, sep=""))) %>% 
  left_join(DataModel, by="Id")

p1 <- ggplot()+geom_sf(data=USC %>% 
                         dplyr::mutate(IndRep=ifelse(IndRep==0, "DEM", "REP")), 
                       colour = "gray60", aes(fill=IndRep))+
  coord_sf(xlim = c(-125,-68), ylim = c(24.5,50)) +
  scale_fill_manual(name="Republican", values=c("blue", "red"))


p1 <- ggplot()+geom_sf(data=USC, 
                       colour = "gray80", aes(fill=votesREP))+
  coord_sf(xlim = c(-125,-68), ylim = c(24.5,50)) +
  scale_fill_gradient2(name="Rep (%)", low="blue", mid="white" , high = "red",
                       midpoint=0.5)


p1 <- p1 +
  xlab("Longitude")+
  ylab("Latitude")+ggspatial::annotation_scale(
    location = "tl",
    bar_cols = c("grey60", "white")
  ) +
  ggspatial::annotation_north_arrow(
    location = "bl", which_north = "true",
    pad_x = unit(0, "in"), pad_y = unit(0, "in"),
    style = ggspatial::north_arrow_nautical(
      fill = c("grey40", "white"),
      line_col = "grey20"
    )
  )

p1
ggsave("US_2020.pdf",p1,width = 10, height = 6, dpi = 300, units = "in")


sf_use_s2(FALSE)

USCNa <- USC %>% dplyr::filter(!is.na(votesREP)) %>% 
  fill(POVALL_2021, MEDHHINC_2021,
       Civilian_labor_force_2020, Employed_2020,Unemployment_rate_2020,
       PorcLess, PorcHigh, PorcOverHigh, PorcBachelor, votesREP,
       TasaNac, PorcMigInt, Poverty, IndRep)

cont.nb<-poly2nb(USCNa) 	# from the spdep:: package
cont.listw<-nb2listw(cont.nb, style="W",zero.policy=T)		# from the spdep:: package
matstand=nb2mat(cont.nb, zero.policy = TRUE)
W = Matrix(matstand, sparse = TRUE)

#### Una binomial
load("TemporalModels.RData")

out1 <- GEESAR(cbind(REPUBLICAN, votes-REPUBLICAN)~  MEDHHINC_2021+Civilian_labor_force_2020+
                 Unemployment_rate_2020+PorcLess+PorcHigh+TasaNac+PorcMigInt+Poverty,
               family=binomial(), data=USCNa,
       W=W, weights = NULL)


save(out1, USCNa, file="TemporalModels.RData")
out2 <- GEESAR(ifelse(votesREP>0.5,1,0)~  MEDHHINC_2021+Civilian_labor_force_2020+
                 Unemployment_rate_2020+PorcLess+TasaNac+PorcMigInt+Poverty,
               family=binomial(), data=USCNa,
               W=W, weights = NULL)


save(out1,out2, USCNa, file="TemporalModels.RData")

out3 <- GEESAR(votesREP~  MEDHHINC_2021+Civilian_labor_force_2020+
                 Unemployment_rate_2020+PorcLess+PorcHigh+TasaNac+
                 PorcMigInt+Poverty,
               family=binomial(), data=USCNa,
               W=W, weights = NULL)

save(out1,out2,out3,  USCNa, file="TemporalModels.RData")

out1$rho
out1$coefficients
plot(as.ts(out1$tracerho))

out1$rho
Coef <- out1$coefficients
SD <- sqrt(diag(out1$naive))
Tabla <- cbind(Coef, SD, Coef/SD, 2*pnorm(-abs(Coef/SD)))
colnames(Tabla) <- c("Estimate", "standar_error", "z_value", "p_value")
rownames(Tabla) <- c( "(Intercept)","MEDHHINC","Civ_lab_force", "Unemp_rate",
                      "PorcLess","PorcHigh","TasaNac","PorcMigInt","Poverty")
Tabla = as.data.frame(Tabla)
A = solve(diag(length(out1$y))-out1$rho*W)
Tabla$Direct = 0
Tabla$Indirect = 0
Tabla$Total = 0
for(i in 1:9){
  S_k = Tabla$Estimate[i]*A
  Tabla$Direct[i] <-   mean(diag(S_k))
  Tabla$Total[i] = mean(colSums(S_k))
  Tabla$Indirect[i] = Tabla$Total[i]-Tabla$Direct[i]
}

Tabla

print(xtable::xtable(Tabla, digits=5), digits=5)

round(out1$coefficients, 6)
plot(as.ts(out1$tracerho))

#### SARAR

out4 <- spreg(votesREP~  MEDHHINC_2021+Civilian_labor_force_2020+
                Unemployment_rate_2020+PorcLess+PorcHigh+TasaNac+PorcMigInt+Poverty,
                data=USCNa, model="lag", listw =W,het=TRUE)



out4$coefficients
out1$coefficients


USCNa$Wy = as.matrix(W)%*%USCNa$REPUBLICAN

out2 <- glm(cbind(REPUBLICAN, votes-REPUBLICAN)~  MEDHHINC_2021+Civilian_labor_force_2020+
              Employed_2020+Unemployment_rate_2020+PorcLess+PorcHigh+TasaNac+PorcMigInt+Poverty+
              Wy,
            family=binomial(), data=USCNa)



round(out2$coefficients,6)
data.frame("glm"=out2$fitted.values, "geesar" = c(out1$fitted.values), "y"=c(factor(out1$y))) %>% 
  ggplot(aes(x=glm, y=geesar, col=y))+
  geom_point()




#### Una gamma

out1 <- GEESAR(formula = price~license+minimum_nights+
                 number_of_reviews,
               family=Gamma(link = "log"), data=DatosF,
               W=W, weights = NULL)


plot(as.ts(out1$tracerho))
out1$rho
out1$coefficients



plot(density(log(DatosF$price)))

DatosF$Wy = as.matrix(W)%*%DatosF$price
out2 <- glm(formula = price~license+minimum_nights+
                 number_of_reviews+Wy,
               family=Gamma(link = "log"), data=DatosF)

round(out2$coefficients,6)


out3 <- lagsarlm(formula = log(price)~license+minimum_nights+
                   number_of_reviews, data=DatosF, listw = Wdist.list.tot)

out3$rho
